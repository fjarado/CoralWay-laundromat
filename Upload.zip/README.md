# laundromat
Testing a laundromat
